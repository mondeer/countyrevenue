<?php

namespace revenue;

use Illuminate\Database\Eloquent\Model;

class defaulters extends Model
{
    protected $fillable = [ 'motorbike_reg','defaulter_amount'];

}
