

<?php $__env->startSection('content'); ?>
  <div class="row">
  
    <div class="panel panel-body">
      <h1>Registered Motorcycles in the county</h1>
      <table class="table table-striped table-positive table-hover">

                <thead>
                <tr>
                    <th><i class="fa fa-user"></i> Id.</th>
                    <th><i class="fa fa-user"></i> Owner Name</th>
                    <th><i class="fa fa-user"></i> Gender</th>
                    <th><i class="fa fa-user"></i> Motorcycle Reg. No.</th>
                    <th><i class="fa fa-user"></i> Date of Purchase</th>
                    <th><i class="fa fa-user"></i> Phone</th>
                    <th>Edit</th>
                </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $motors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($motor->id); ?></td>
                            <td><?php echo e($motor->owner_name); ?></td>
                            <td><?php echo e($motor->gender); ?></td>
                            <td><?php echo e($motor->motorbike_reg); ?></td>
                            <td><?php echo e($motor->dop); ?></td>
                            <td><?php echo e($motor->phone); ?></td>
                            <td>
                              <a class="btn btn-primary" href="/motor/<?php echo e($motor->id); ?>/edit">Edit</a>
                            </td>
                            <td>
                              <a class="btn btn-primary" href="/revenue/create/<?php echo e($motor->id); ?>">Pay</a>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
              </table>

    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>