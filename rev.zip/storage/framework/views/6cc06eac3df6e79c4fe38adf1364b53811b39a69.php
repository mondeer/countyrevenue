<?php $__env->startSection('content'); ?>
  <div class="row">

    <div class="panel panel-body">
      <h1>Revenue Defaulters</h1>
      <table class="table table-striped table-positive table-hover">

                <thead>
                <tr>
                    <th><i class="fa fa-user"></i> Id.</th>
                    <th><i class="fa fa-user"></i> Owner Name</th>
                    <th><i class="fa fa-user"></i> Month</th>
                    <th><i class="fa fa-user"></i> Motorbike Reg</th>

                </tr>
                </thead>
                <tbody>
                  <?php echo e($now = Carbon\carbon::now()); ?>

                    <?php $__currentLoopData = $motorevs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                              <td>
                                <?php echo e($motorev->id); ?>

                              </td>
                              <td>
                                <?php echo e($motorev->owner_name); ?>

                              </td>
                              <td>
                                <?php echo e($now->month); ?>

                              </td>
                              <td>
                                <?php echo e($motorev->motorbike_reg); ?>

                              </td>
                            </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </table>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>