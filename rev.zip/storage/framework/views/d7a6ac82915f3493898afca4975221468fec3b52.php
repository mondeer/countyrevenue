

<?php $__env->startSection('audit'); ?>
<div class="row">

  <div class="panel panel-body">
    
    <table class="table table-striped table-positive table-hover">

              <thead>
              <tr>
                  <th><i class="fa fa-user"></i> Id.</th>
                  <th><i class="fa fa-user"></i> Owner Name</th>
                  <th><i class="fa fa-user"></i> Month</th>
                  <th><i class="fa fa-user"></i> Motorbike Reg</th>

              </tr>
              </thead>
              <tbody>

                  <?php $__currentLoopData = $revenues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <tr>
                            <td>
                              <?php echo e($revenue->id); ?>

                            </td>
                            <td>
                              <?php echo e($revenue->month); ?>

                            </td>
                          </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('clerk.audit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>